"""
Linear-equivalence for **arbitrary** (possibly non-permutation) functions.

`are_linearly_equivalent_perm` (the LPP backtracking) assumes both
S-boxes are permutations — it follows the functional inverse and silently
returns `false` for non-bijective inputs. But the central APN use-case is
non-bijective: almost every APN function is 3-to-1, and the ortho-derivative
EA-test reduces EA-equivalence of quadratic APN to **linear**-equivalence of the
ortho-derivatives, which are themselves non-permutations.

[`are_linearly_equivalent_general`](@ref) decides linear-equivalence without
assuming bijectivity. It searches for invertible `L₁, L₂` with `G = L₁∘F∘L₂` by
guessing `L₂` on the standard basis (each image kept independent of the previous,
so `L₂` stays invertible) and, for every point of the span fixed so far,
propagating the constraint `L₁(F(L₂(x))) = G(x)` into a partial linear map `L₁`
maintained in row-reduced form. A branch dies on the first inconsistency; a
complete `L₂` with a full-rank `L₁` is a witness.
"""

# Partial linear map: RREF inputs `bin`/outputs `bout`; _lin_add! folds L(u)=v.
function _lin_add!(bin::Vector{Int}, bout::Vector{Int}, u::Integer, v::Integer)
    r = Int(u)
    o = Int(v) & 0   # o accumulates the output of the reduced part
    o = 0
    @inbounds for k in eachindex(bin)
        p = bin[k]
        hb = 1 << (8 * sizeof(Int) - 1 - leading_zeros(p))   # high set bit of p
        if r & hb != 0
            r ⊻= p
            o ⊻= bout[k]
        end
    end
    if r == 0
        return Int(v) == o            # fully reduced ⇒ L(u) is fixed; check it
    else
        push!(bin, r)
        push!(bout, Int(v) ⊻ o)        # L(r) = v ⊻ o
        return true
    end
end

"""
    linear_equivalences_general(F::SBox{N,T}, G::SBox{N,T})
        -> Vector{NamedTuple{(:L1, :L2), ...}}

Collect **all** invertible pairs `(L₁, L₂)` with `G = L₁∘F∘L₂`, for
arbitrary (possibly non-permutation) `F, G` — the collect-all companion
of [`are_linearly_equivalent_general`](@ref) and the non-permutation
counterpart of [`linear_equivalences`](@ref) (same `(L₁, L₂)`
convention). Solutions whose propagated constraints do not fully
determine `L₁` (image span of `F∘L₂` below full rank) are skipped —
this cannot occur when `F`'s image spans `F₂ⁿ`.

Used by [`automorphisms_from_ortho_derivative`](@ref) to enumerate the
linear self-equivalences of non-bijective ortho-derivatives (every
quadratic APN in even dimension).
"""
function linear_equivalences_general(F::SBox{N,T}, G::SBox{N,T}) where {N,T}
    out = NamedTuple{(:L1, :L2),Tuple{F2LinearMap{N,T},F2LinearMap{N,T}}}[]
    differential_spectrum(F) == differential_spectrum(G) || return out
    absolute_walsh_spectrum(F) == absolute_walsh_spectrum(G) || return out
    NN = 1 << N
    Fl = F.lut
    Gl = G.lut
    L2 = fill(-1, NN)
    L2[1] = 0
    used = Int[]
    sols = Vector{Tuple{Vector{Int},Vector{Int},Vector{Int}}}()

    indep = function (v::Int)
        v == 0 && return false
        r = v
        @inbounds for u in used
            hb = 1 << (8 * sizeof(Int) - 1 - leading_zeros(u))
            r & hb != 0 && (r ⊻= u)
        end
        r != 0
    end

    rec = function (i::Int, bin::Vector{Int}, bout::Vector{Int})
        if i == N
            rank_f2(UInt32.(bout); nbits = N) == length(bin) &&
                push!(sols, (copy(used), copy(bin), copy(bout)))
            return
        end
        b = 1 << i
        @inbounds for img = 1:(NN-1)
            indep(img) || continue
            bin2 = copy(bin)
            bout2 = copy(bout)
            newpos = Int[]
            ok = true
            for x = 0:(NN-1)
                x >> i == 0 || continue
                nx = x ⊻ b
                L2[nx+1] = L2[x+1] ⊻ img
                push!(newpos, nx)
                if !_lin_add!(bin2, bout2, Fl[L2[nx+1]+1], Gl[nx+1])
                    ok = false
                    break
                end
            end
            if ok
                push!(used, img)
                rec(i + 1, bin2, bout2)
                pop!(used)
            end
            for p in newpos
                L2[p+1] = -1
            end
        end
    end

    bin = Int[]
    bout = Int[]
    _lin_add!(bin, bout, Fl[1], Gl[1])
    rec(0, bin, bout)

    for (l2imgs, sbin, sbout) in sols
        M2 = F2LinearMap{N,T}(T.(l2imgs))
        # Reconstruct L₁ from the propagated constraints L₁(sbin[k]) = sbout[k];
        # skip if underdetermined (constraint span below full rank).
        length(sbin) == N || continue
        cols = Vector{T}(undef, N)
        determined = true
        for i = 0:(N-1)
            r = 1 << i
            o = 0
            changed = true
            while changed && r != 0
                changed = false
                for k in eachindex(sbin)
                    p = sbin[k]
                    hb = 1 << (8 * sizeof(Int) - 1 - leading_zeros(p))
                    if r & hb != 0
                        r ⊻= p
                        o ⊻= sbout[k]
                        changed = true
                    end
                end
            end
            if r != 0
                determined = false
                break
            end
            cols[i+1] = T(o)
        end
        determined || continue
        M1 = F2LinearMap{N,T}(cols)
        is_invertible(M1) || continue
        all(M1(Fl[M2(T(x))+1]) == Gl[x+1] for x = 0:(NN-1)) &&
            push!(out, (L1 = M1, L2 = M2))
    end
    return out
end

"""
    are_linearly_equivalent_general(F::SBox{N,T}, G::SBox{N,T}) -> Bool

Decide whether invertible F₂-linear maps `L₁, L₂` exist with `G = L₁∘F∘L₂`,
for arbitrary (possibly non-permutation) `F, G`. See the module docstring.
"""
function are_linearly_equivalent_general(F::SBox{N,T}, G::SBox{N,T}) where {N,T}
    differential_spectrum(F) == differential_spectrum(G) || return false
    absolute_walsh_spectrum(F) == absolute_walsh_spectrum(G) || return false
    NN = 1 << N
    Fl = F.lut
    Gl = G.lut
    L2 = fill(-1, NN)
    L2[1] = 0       # L₂(0) = 0
    used = Int[]                       # chosen L₂ basis images

    # is `v` independent of the images chosen so far (so L₂ stays invertible)?
    indep = function (v::Int)
        v == 0 && return false
        r = v
        @inbounds for u in used
            hb = 1 << (8 * sizeof(Int) - 1 - leading_zeros(u))
            r & hb != 0 && (r ⊻= u)
        end
        r != 0
    end

    rec = function (i::Int, bin::Vector{Int}, bout::Vector{Int})
        i == N && return rank_f2(UInt32.(bout); nbits = N) == length(bin)
        b = 1 << i
        @inbounds for img = 1:(NN-1)
            indep(img) || continue
            bin2 = copy(bin)
            bout2 = copy(bout)
            newpos = Int[]
            ok = true
            for x = 0:(NN-1)  # span of basis bits 0..i-1 is x < 2^i
                x >> i == 0 || continue
                nx = x ⊻ b
                L2[nx+1] = L2[x+1] ⊻ img
                push!(newpos, nx)
                if !_lin_add!(bin2, bout2, Fl[L2[nx+1]+1], Gl[nx+1])
                    ok = false
                    break
                end
            end
            if ok
                push!(used, img)
                rec(i + 1, bin2, bout2) && return true
                pop!(used)
            end
            for p in newpos
                L2[p+1] = -1
            end
        end
        false
    end

    bin = Int[]
    bout = Int[]
    _lin_add!(bin, bout, Fl[1], Gl[1])              # F(L₂(0)) = F(0) ↦ G(0)
    rec(0, bin, bout)
end
